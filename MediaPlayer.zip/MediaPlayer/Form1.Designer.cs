﻿namespace MediaPlayer
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_pdf = new System.Windows.Forms.Button();
            this.btn_nav = new System.Windows.Forms.Button();
            this.btn_browser = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_pdf
            // 
            this.btn_pdf.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btn_pdf.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_pdf.Font = new System.Drawing.Font("Broadway", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_pdf.Location = new System.Drawing.Point(127, 153);
            this.btn_pdf.Name = "btn_pdf";
            this.btn_pdf.Size = new System.Drawing.Size(81, 33);
            this.btn_pdf.TabIndex = 0;
            this.btn_pdf.Text = "PDF";
            this.btn_pdf.UseVisualStyleBackColor = false;
            this.btn_pdf.MouseClick += new System.Windows.Forms.MouseEventHandler(this.abrirPDF);
            // 
            // btn_nav
            // 
            this.btn_nav.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btn_nav.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_nav.Font = new System.Drawing.Font("Broadway", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_nav.Location = new System.Drawing.Point(214, 153);
            this.btn_nav.Name = "btn_nav";
            this.btn_nav.Size = new System.Drawing.Size(111, 33);
            this.btn_nav.TabIndex = 1;
            this.btn_nav.Text = "Navegador";
            this.btn_nav.UseVisualStyleBackColor = false;
            this.btn_nav.Click += new System.EventHandler(this.btn_nav_Click);
            // 
            // btn_browser
            // 
            this.btn_browser.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btn_browser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_browser.Font = new System.Drawing.Font("Broadway", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_browser.Location = new System.Drawing.Point(23, 153);
            this.btn_browser.Name = "btn_browser";
            this.btn_browser.Size = new System.Drawing.Size(98, 33);
            this.btn_browser.TabIndex = 2;
            this.btn_browser.Text = "Audio";
            this.btn_browser.UseVisualStyleBackColor = false;
            this.btn_browser.Click += new System.EventHandler(this.btn_browser_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::MediaPlayer.Properties.Resources.prueba;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(337, 326);
            this.Controls.Add(this.btn_browser);
            this.Controls.Add(this.btn_nav);
            this.Controls.Add(this.btn_pdf);
            this.Name = "Form1";
            this.Text = "Eventos";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_pdf;
        private System.Windows.Forms.Button btn_nav;
        private System.Windows.Forms.Button btn_browser;
    }
}

