﻿using System;
using System.Windows.Forms;
using System.Diagnostics;

namespace MediaPlayer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public string FileName { get; private set; }

        private void abrirPDF(object sender, MouseEventArgs e)
        {
            string filePath = @"C:\Users\Carlos Banol\source\repos\MediaPlayer\MediaPlayer\imgs\vpn.pdf";
            try
            {
                Process.Start(filePath);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"No se pudo abrir el archivo PDF, ERROR: {ex.Message}");
            }
        }

        private void btn_browser_Click(object sender, EventArgs e)
        {
            string filePath = @"C:\Program Files (x86)\Windows Media Player\wmplayer.exe";
            try
            {
                Process.Start(filePath);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ocurrió un error: {ex.Message}");
            }
        }

        private void btn_nav_Click(object sender, EventArgs e)
        {
            string filePath = @"C:\Program Files\Google\Chrome\Application\chrome.exe";
            try
            {
                Process.Start(filePath);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ocurrió un error: {ex.Message}");
            }
        }
    }
}
